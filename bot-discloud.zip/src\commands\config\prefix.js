const { SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');
const { getPrefix, setPrefix } = require('../../utils/prefixManager');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('prefix')
        .setDescription('Configure the bot prefix for text commands')
        .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
        .addStringOption(option =>
            option.setName('new_prefix')
                .setDescription('The new prefix (type "none" to completely disable prefixes)')
                .setRequired(true)
        ),

    async execute(interaction) {
        const newPrefix = interaction.options.getString('new_prefix').toLowerCase();

        if (newPrefix === 'none') {
            setPrefix(interaction.guild.id, 'none');
            return interaction.reply({ embeds: [createSuccessEmbed('Prefixes have been completely **disabled** on this server. You can now type command names purely through text!')] });
        }

        if (newPrefix.length > 5) {
            return interaction.reply({ embeds: [createErrorEmbed('Prefix must be 5 characters or shorter.')], ephemeral: true });
        }

        setPrefix(interaction.guild.id, newPrefix);
        return interaction.reply({ embeds: [createSuccessEmbed(`The server prefix has been updated to **${newPrefix}**.`)] });
    }
};
