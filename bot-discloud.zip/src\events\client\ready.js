const { Events } = require('discord.js');

module.exports = {
    name: Events.ClientReady,
    once: true,
    async execute(client) {
        console.log(`Ready! Logged in as ${client.user.tag}`);
        client.user.setPresence({
            activities: [{ name: 'Bunny Hub', type: 3 }], // 3 = WATCHING
            status: 'online',
        });
    },
};
