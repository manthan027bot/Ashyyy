const { SlashCommandBuilder } = require('discord.js');
const playCommand = require('./play');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('p')
        .setDescription('Alias for /play')
        .addStringOption(option =>
            option.setName('query')
                .setDescription('Song name or URL')
                .setRequired(true)
        ),
    async execute(interaction, client) {
        return playCommand.execute(interaction, client);
    }
};
