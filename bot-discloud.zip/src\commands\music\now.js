const { SlashCommandBuilder } = require('discord.js');
const nowplayingCommand = require('./nowplaying');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('now')
        .setDescription('Alias for /nowplaying'),
    async execute(interaction, client) {
        return nowplayingCommand.execute(interaction, client);
    }
};
