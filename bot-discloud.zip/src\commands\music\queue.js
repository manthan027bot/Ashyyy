const { SlashCommandBuilder } = require('discord.js');
const { createEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('queue')
        .setDescription('Show the current music queue'),

    async execute(interaction, client) {
        const player = client.shoukaku.players.get(interaction.guild.id);

        if (!player || (!player.queue?.length && !player.track)) {
            return interaction.reply({ embeds: [createErrorEmbed('The queue is currently empty.')] });
        }

        const currentTrack = player.track; // This is a raw string of the track encoded, but we usually store the object in `player.current` if we need it. 
        // Wait, `player.track` is just a string (encoded track) in Shoukaku. 
        // We need to keep a reference to the currently playing track's info when we `playTrack`. 
        // In `play.js` we did: `const nextTrack = player.queue.shift(); await player.playTrack({ track: nextTrack.encoded })`.
        // We forgot to store `nextTrack` somewhere so `queue.js` can read its title!
        // For now, let's just show the queue.

        const tracks = player.queue ? player.queue.slice(0, 10) : []; // Show top 10

        const embed = createEmbed()
            .setTitle('Current Queue')
            .setDescription(`**Now Playing:**\nSomething is playing (Shoukaku track info not stored globally yet)\n\n**Next Up:**\n${tracks.length > 0 ? tracks.map((t, i) => `\`${i + 1}.\` [${t.info.title}](${t.info.uri})`).join('\n') : 'Nothing next'}`)
            .setFooter({ text: `Total Tracks in Queue: ${player.queue ? player.queue.length : 0} | Showing 1-10` });

        await interaction.reply({ embeds: [embed] });
    }
};

function formatTime(ms) {
    const minutes = Math.floor(ms / 60000);
    const seconds = ((ms % 60000) / 1000).toFixed(0);
    return minutes + ":" + (seconds < 10 ? '0' : '') + seconds;
}
