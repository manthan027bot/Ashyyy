require('dotenv').config();
const BotClient = require('./structures/BotClient');

const client = new BotClient();



// Handle process errors to prevent crash
process.on('unhandledRejection', (reason, promise) => {
    console.error('Unhandled Rejection at:', promise, 'reason:', reason);
});

process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
});

client.start();
