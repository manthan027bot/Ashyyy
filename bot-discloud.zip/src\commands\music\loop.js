const { SlashCommandBuilder } = require('discord.js');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('loop')
        .setDescription('Toggle looping the current track or queue')
        .addStringOption(option =>
            option.setName('mode')
                .setDescription('The loop mode')
                .setRequired(true)
                .addChoices(
                    { name: 'Track', value: 'track' },
                    { name: 'Queue', value: 'queue' },
                    { name: 'Off', value: 'off' }
                )
        ),

    async execute(interaction, client) {
        const player = client.shoukaku.players.get(interaction.guild.id);
        if (!player) return interaction.reply({ embeds: [createErrorEmbed('No music is playing!')], ephemeral: true });

        const mode = interaction.options.getString('mode');
        player.loopState = mode;

        return interaction.reply({ embeds: [createSuccessEmbed(`Looping is now set to **${mode}**.`)] });
    }
};
