const { EmbedBuilder } = require('discord.js');

const COLORS = {
    DEFAULT: '#2b2d31',
    SUCCESS: '#43b581',
    ERROR: '#f04747',
    INFO: '#7289da'
};

function createEmbed(type = 'DEFAULT') {
    return new EmbedBuilder()
        .setColor(COLORS[type] || COLORS.DEFAULT)
        .setTimestamp();
}

function createErrorEmbed(message) {
    return createEmbed('ERROR')
        .setDescription(`❌ **${message}**`);
}

function createSuccessEmbed(message) {
    return createEmbed('SUCCESS')
        .setDescription(`✅ **${message}**`);
}

module.exports = {
    createEmbed,
    createErrorEmbed,
    createSuccessEmbed,
    COLORS
};
