const { SlashCommandBuilder } = require('discord.js');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('dc')
        .setDescription('Stop playing and disconnect from the voice channel'),
    async execute(interaction, client) {
        const player = client.shoukaku.players.get(interaction.guild.id);
        if (!player) return interaction.reply({ embeds: [createErrorEmbed('I am not connected to a voice channel!')], ephemeral: true });

        client.shoukaku.leaveVoiceChannel(interaction.guild.id);
        return interaction.reply({ embeds: [createSuccessEmbed('Disconnected from the voice channel.')] });
    }
};
