const { SlashCommandBuilder } = require('discord.js');
const { createSuccessEmbed, createErrorEmbed, createEmbed } = require('../../utils/embeds');
const { buildNowPlayingMenu } = require('../../utils/musicMenu');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('join')
        .setDescription('Join your voice channel without playing anything'),
    async execute(interaction, client) {
        if (!interaction.member.voice.channel) {
            return interaction.reply({ embeds: [createErrorEmbed('You need to be in a voice channel first!')], ephemeral: true });
        }

        let player = client.shoukaku.players.get(interaction.guild.id);
        if (player) {
            return interaction.reply({ embeds: [createErrorEmbed('I am already connected to a voice channel!')], ephemeral: true });
        }

        try {
            player = await client.shoukaku.joinVoiceChannel({
                guildId: interaction.guild.id,
                channelId: interaction.member.voice.channel.id,
                shardId: interaction.guild.shardId
            });

            player.textChannelId = interaction.channel.id;

            player.on('start', async () => {
                const channel = client.channels.cache.get(player.textChannelId);
                if (!channel) return;

                const menuPayload = await buildNowPlayingMenu(client, player);
                if (menuPayload) {
                    channel.send(menuPayload).catch(console.error);
                }
            });

            player.on('end', async (data) => {
                if (data.reason === 'replaced') return;

                // Handle looping
                if (player.loopState === 'track' && player.track) {
                    return await player.playTrack({ track: { encoded: player.track } }).catch(console.error);
                }

                if (player.loopState === 'queue' && player.track) {
                    try {
                        const node = client.shoukaku.options.nodeResolver(client.shoukaku.nodes);
                        const decodedOld = await node.rest.decode(player.track);
                        if (decodedOld) player.queue.push(decodedOld);
                    } catch (e) {
                        console.error('[Shoukaku] Failed to decode track for queue loop', e);
                    }
                }

                // Keep track of the last played track for Autoplay
                if (player.track) {
                    try {
                        const node = client.shoukaku.options.nodeResolver(client.shoukaku.nodes);
                        const decodedEnded = await node.rest.decode(player.track);
                        if (decodedEnded) player.previousTrack = decodedEnded;
                    } catch (e) {
                        console.error('[Shoukaku] Failed to decode ended track', e);
                    }
                }

                if (player.queue && player.queue.length > 0) {
                    const nextTrack = player.queue.shift();
                    await player.playTrack({ track: { encoded: nextTrack.encoded } }).catch(console.error);
                } else if (player.isAutoplay && player.previousTrack && player.previousTrack.info.sourceName === 'youtube') {
                    // Handle Autoplay logic for YouTube
                    try {
                        const node = client.shoukaku.options.nodeResolver(client.shoukaku.nodes);
                        const searchStr = `ytsearch:${player.previousTrack.info.author} mix`;
                        const result = await node.rest.resolve(searchStr);

                        if (result && result.data && result.data.length > 0) {
                            const relatedTrack = result.data.find(t => t.info.identifier !== player.previousTrack.info.identifier) || result.data[0];
                            player.queue.push(relatedTrack);
                            const nextTrack = player.queue.shift();

                            await player.playTrack({ track: { encoded: nextTrack.encoded } }).catch(console.error);

                            const channel = client.channels.cache.get(player.textChannelId);
                            if (channel) {
                                const embed = createEmbed('INFO').setDescription(`Autoplay added **${nextTrack.info.title}** to the queue.`);
                                channel.send({ embeds: [embed] }).catch(console.error);
                            }
                        } else {
                            handleEmptyQueue(client, interaction, player);
                        }
                    } catch (e) {
                        console.error('[Autoplay Error]', e);
                        handleEmptyQueue(client, interaction, player);
                    }
                } else {
                    handleEmptyQueue(client, interaction, player);
                }

                function handleEmptyQueue(c, i, p) {
                    setTimeout(() => {
                        const currentP = c.shoukaku.players.get(i.guild.id);
                        if (currentP && (!currentP.queue || currentP.queue.length === 0) && !currentP.track && !currentP.is247) {
                            c.shoukaku.leaveVoiceChannel(i.guild.id);
                        }
                    }, 60000);
                }
            });

            player.on('error', (err) => console.error('[Shoukaku] Player error:', err));
            player.on('closed', (data) => console.log('[Shoukaku] Player closed:', data));

        } catch (error) {
            console.error('[Shoukaku] Failed to join voice channel:', error);
            return interaction.reply({ embeds: [createErrorEmbed('Failed to join the voice channel.')] });
        }

        return interaction.reply({ embeds: [createSuccessEmbed('Joined the voice channel!')] });
    }
};
