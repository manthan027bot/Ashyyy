const fs = require('fs');
const path = require('path');

const filePath = path.join(__dirname, '../../data/prefixes.json');

// Ensure directory and file exist
if (!fs.existsSync(path.dirname(filePath))) {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
}
if (!fs.existsSync(filePath)) {
    fs.writeFileSync(filePath, JSON.stringify({}, null, 4));
}

let prefixesCache = {};

try {
    const data = fs.readFileSync(filePath, 'utf-8');
    prefixesCache = JSON.parse(data);
} catch (err) {
    console.error('Failed to parse prefixes.json. Starting fresh.', err);
    prefixesCache = {};
}

function savePrefixes() {
    fs.writeFileSync(filePath, JSON.stringify(prefixesCache, null, 4));
}

function getPrefix(guildId) {
    // Returns explicitly set prefix, 'none', or default ('!')
    return prefixesCache[guildId] || '!';
}

function setPrefix(guildId, newPrefix) {
    prefixesCache[guildId] = newPrefix;
    savePrefixes();
}

module.exports = {
    getPrefix,
    setPrefix
};
