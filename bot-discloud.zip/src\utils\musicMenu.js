const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { createEmbed } = require('./embeds');

async function buildNowPlayingMenu(client, player) {
    const node = client.shoukaku.options.nodeResolver(client.shoukaku.nodes);
    const decodedTrack = await node.rest.decode(player.track);

    if (!decodedTrack) return null;
    const info = decodedTrack.info;

    const embed = createEmbed('INFO')
        .setAuthor({ name: 'Now Playing', iconURL: client.user.displayAvatarURL() })
        .setTitle(info.title)
        .setURL(info.uri)
        .addFields([
            { name: 'Author', value: info.author, inline: true },
            { name: 'Duration', value: formatTime(info.length), inline: true },
            { name: 'Volume', value: `${player.volume}%`, inline: true }
        ])
        .setThumbnail(info.artworkUrl || `https://img.youtube.com/vi/${info.identifier}/hqdefault.jpg`)
        .setFooter({ text: player.loopState && player.loopState !== 'off' ? `Loop: ${player.loopState}` : 'Interactive Music Player' });

    const playPauseBtn = new ButtonBuilder()
        .setCustomId('menu_pause')
        .setEmoji(player.paused ? '▶️' : '⏸️')
        .setStyle(player.paused ? ButtonStyle.Success : ButtonStyle.Primary);

    const skipBtn = new ButtonBuilder()
        .setCustomId('menu_skip')
        .setEmoji('⏭️')
        .setStyle(ButtonStyle.Secondary);

    const stopBtn = new ButtonBuilder()
        .setCustomId('menu_stop')
        .setEmoji('⏹️')
        .setStyle(ButtonStyle.Danger);

    const volDownBtn = new ButtonBuilder()
        .setCustomId('menu_voldown')
        .setEmoji('🔉')
        .setStyle(ButtonStyle.Secondary);

    const volUpBtn = new ButtonBuilder()
        .setCustomId('menu_volup')
        .setEmoji('🔊')
        .setStyle(ButtonStyle.Secondary);

    const loopBtn = new ButtonBuilder()
        .setCustomId('menu_loop')
        .setEmoji('🔁')
        .setLabel(player.loopState === 'track' ? 'Track' : player.loopState === 'queue' ? 'Queue' : 'Off')
        .setStyle(player.loopState ? ButtonStyle.Primary : ButtonStyle.Secondary);

    const row1 = new ActionRowBuilder().addComponents(volDownBtn, playPauseBtn, skipBtn, stopBtn, volUpBtn);
    const row2 = new ActionRowBuilder().addComponents(loopBtn);

    return { embeds: [embed], components: [row1, row2] };
}

function formatTime(ms) {
    if (!ms || ms === 0) return '0:00';
    const minutes = Math.floor(ms / 60000);
    const seconds = ((ms % 60000) / 1000).toFixed(0);
    return minutes + ':' + (seconds < 10 ? '0' : '') + seconds;
}

module.exports = { buildNowPlayingMenu };
