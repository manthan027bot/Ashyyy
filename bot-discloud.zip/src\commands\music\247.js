const { SlashCommandBuilder } = require('discord.js');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('247')
        .setDescription('Toggle 24/7 mode'),

    async execute(interaction, client) {
        const player = client.shoukaku.players.get(interaction.guild.id);
        if (!player) return interaction.reply({ embeds: [createErrorEmbed('No music is playing!')], ephemeral: true });

        player.is247 = !player.is247;

        return interaction.reply({ embeds: [createSuccessEmbed(`24/7 mode is now **${player.is247 ? 'Enabled' : 'Disabled'}**.`)] });
    }
};
