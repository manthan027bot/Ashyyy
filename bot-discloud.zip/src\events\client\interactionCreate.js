const { Events } = require('discord.js');

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction, client) {
        if (interaction.isChatInputCommand()) {
            const command = client.commands.get(interaction.commandName);

            if (!command) {
                console.error(`No command matching ${interaction.commandName} was found.`);
                return;
            }

            try {
                await command.execute(interaction, client);
            } catch (error) {
                console.error(error);
                if (interaction.replied || interaction.deferred) {
                    await interaction.followUp({ content: 'There was an error while executing this command!', ephemeral: true });
                } else {
                    await interaction.reply({ content: 'There was an error while executing this command!', ephemeral: true });
                }
            }
        } else if (interaction.isAutocomplete()) {
            const command = client.commands.get(interaction.commandName);
            if (!command) {
                console.error(`No command matching ${interaction.commandName} was found.`);
                return;
            }
            try {
                await command.autocomplete(interaction, client);
            } catch (error) {
                console.error(error);
            }
        } else if (interaction.isButton()) {
            const player = client.shoukaku.players.get(interaction.guild.id);
            if (!player) return interaction.reply({ content: 'No music is playing.', ephemeral: true });

            const { customId } = interaction;
            try {
                if (customId === 'pause' || customId === 'menu_pause') {
                    await player.setPaused(!player.paused);
                    await interaction.reply({ content: player.paused ? 'Paused' : 'Resumed', ephemeral: true });
                } else if (customId === 'skip' || customId === 'menu_skip') {
                    await player.stopTrack(); // this triggers the 'end' event which plays the next track
                    await interaction.reply({ content: 'Skipped', ephemeral: true });
                } else if (customId === 'stop' || customId === 'menu_stop') {
                    client.shoukaku.leaveVoiceChannel(interaction.guild.id);
                    await interaction.reply({ content: 'Stopped and disconnected', ephemeral: true });
                } else if (customId === 'vol_up' || customId === 'menu_volup') {
                    const newVol = Math.min(player.volume + 10, 100);
                    await player.setGlobalVolume(newVol);
                    await interaction.reply({ content: `Volume increased to ${newVol}%`, ephemeral: true });
                } else if (customId === 'vol_down' || customId === 'menu_voldown') {
                    const newVol = Math.max(player.volume - 10, 0);
                    await player.setGlobalVolume(newVol);
                    await interaction.reply({ content: `Volume decreased to ${newVol}%`, ephemeral: true });
                } else if (customId === 'menu_loop') {
                    if (!player.loopState || player.loopState === 'off') {
                        player.loopState = 'queue';
                    } else if (player.loopState === 'queue') {
                        player.loopState = 'track';
                    } else {
                        player.loopState = 'off';
                    }
                    await interaction.reply({ content: `Looping is now set to **${player.loopState}**`, ephemeral: true });
                }
            } catch (error) {
                console.error(error);
                await interaction.reply({ content: 'Error interacting with player', ephemeral: true });
            }
        }
    },
};
