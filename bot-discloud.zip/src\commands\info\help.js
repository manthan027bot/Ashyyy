const { SlashCommandBuilder } = require('discord.js');
const { createEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('help')
        .setDescription('Shows all available commands for Ashyyy'),

    async execute(interaction, client) {
        const embed = createEmbed('INFO')
            .setTitle('🎸 Ashyyy - Help Menu')
            .setDescription('Here are all the amazing features you can use with **Ashyyy**!')
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
            .addFields(
                {
                    name: '🎵 Music Commands',
                    value: '`> /play <query>` - Play a song or playlist\n`> /nowplaying` - View the currently playing song\n`> /queue` - View the server queue\n`> /loop <off|track|queue>` - Loop the current track or queue\n`> /filter <type>` - Apply audio filters (bassboost, nightcore, etc)\n`> /autoplay` - Toggle autoplay for continuous music\n`> /247` - Toggle 24/7 mode in the voice channel',
                    inline: false
                },
                {
                    name: '⚙️ Configuration',
                    value: "`> /prefix <new_prefix>` - Change the bot's text prefix(if message commands are enabled) \n`> /help` - Shows this help menu",
                    inline: false
                }
            )
            .setFooter({ text: 'Ashyyy Music Bot', iconURL: client.user.displayAvatarURL({ dynamic: true }) });

        return interaction.reply({ embeds: [embed] });
    }
};
