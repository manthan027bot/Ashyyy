const { SlashCommandBuilder, ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require('discord.js');
const { createErrorEmbed, createSuccessEmbed, createEmbed } = require('../../utils/embeds');
const { buildNowPlayingMenu } = require('../../utils/musicMenu');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('play')
        .setDescription('Play a song from YouTube, Spotify, or SoundCloud')
        .addStringOption(option =>
            option.setName('query')
                .setDescription('Song name or URL')
                .setRequired(true)
        ),

    async execute(interaction, client) {
        if (!interaction.member.voice.channel) {
            return interaction.reply({ embeds: [createErrorEmbed('You need to be in a voice channel to play music!')], ephemeral: true });
        }

        const query = interaction.options.getString('query');
        await interaction.deferReply();

        let player = client.shoukaku.players.get(interaction.guild.id);
        const node = client.shoukaku.options.nodeResolver(client.shoukaku.nodes);

        if (!player) {
            try {
                player = await client.shoukaku.joinVoiceChannel({
                    guildId: interaction.guild.id,
                    channelId: interaction.member.voice.channel.id,
                    shardId: interaction.guild.shardId
                });

                player.textChannelId = interaction.channel.id;

                player.on('start', async () => {
                    const channel = client.channels.cache.get(player.textChannelId);
                    if (!channel) return;

                    const menuPayload = await buildNowPlayingMenu(client, player);
                    if (menuPayload) {
                        channel.send(menuPayload).catch(console.error);
                    }
                });

                player.on('end', async (data) => {
                    if (data.reason === 'replaced') return;

                    // Handle looping
                    if (player.loopState === 'track' && player.track) {
                        return await player.playTrack({ track: { encoded: player.track } }).catch(console.error);
                    }

                    if (player.loopState === 'queue' && player.track) {
                        try {
                            const node = client.shoukaku.options.nodeResolver(client.shoukaku.nodes);
                            const decodedOld = await node.rest.decode(player.track);
                            if (decodedOld) player.queue.push(decodedOld);
                        } catch (e) {
                            console.error('[Shoukaku] Failed to decode track for queue loop', e);
                        }
                    }

                    // Keep track of the last played track for Autoplay
                    if (player.track) {
                        try {
                            const node = client.shoukaku.options.nodeResolver(client.shoukaku.nodes);
                            const decodedEnded = await node.rest.decode(player.track);
                            if (decodedEnded) player.previousTrack = decodedEnded;
                        } catch (e) {
                            console.error('[Shoukaku] Failed to decode ended track', e);
                        }
                    }

                    if (player.queue && player.queue.length > 0) {
                        const nextTrack = player.queue.shift();
                        await player.playTrack({ track: { encoded: nextTrack.encoded } }).catch(console.error);
                    } else if (player.isAutoplay && player.previousTrack && player.previousTrack.info.sourceName === 'youtube') {
                        // Handle Autoplay logic for YouTube
                        try {
                            const node = client.shoukaku.options.nodeResolver(client.shoukaku.nodes);
                            // Some Lavalink plugins use ytsearch:related: or ytsearch: <video> mix. We search by author/title to be safe if 'related:' isn't supported, 
                            // but usually it is preferable to just search youtube recommended if the Lavalink node supports it. Here we use an artist-based search as a fallback mix.
                            const searchStr = `ytsearch:${player.previousTrack.info.author} mix`;
                            const result = await node.rest.resolve(searchStr);

                            if (result && result.data && result.data.length > 0) {
                                // Find a track that isn't exactly the one we just played
                                const relatedTrack = result.data.find(t => t.info.identifier !== player.previousTrack.info.identifier) || result.data[0];
                                player.queue.push(relatedTrack);
                                const nextTrack = player.queue.shift();

                                await player.playTrack({ track: { encoded: nextTrack.encoded } }).catch(console.error);

                                const channel = client.channels.cache.get(player.textChannelId);
                                if (channel) {
                                    const { createEmbed } = require('../../utils/embeds');
                                    const embed = createEmbed('INFO').setDescription(`Autoplay added **${nextTrack.info.title}** to the queue.`);
                                    channel.send({ embeds: [embed] }).catch(console.error);
                                }
                            } else {
                                handleEmptyQueue(client, interaction, player);
                            }
                        } catch (e) {
                            console.error('[Autoplay Error]', e);
                            handleEmptyQueue(client, interaction, player);
                        }
                    } else {
                        handleEmptyQueue(client, interaction, player);
                    }

                    function handleEmptyQueue(c, i, p) {
                        // Wait 1 min before leaving if queue is still empty (and not 24/7)
                        setTimeout(() => {
                            const currentP = c.shoukaku.players.get(i.guild.id);
                            if (currentP && (!currentP.queue || currentP.queue.length === 0) && !currentP.track && !currentP.is247) {
                                c.shoukaku.leaveVoiceChannel(i.guild.id);
                            }
                        }, 60000);
                    }
                });

                player.on('error', (err) => console.error('[Shoukaku] Player error:', err));
                player.on('closed', (data) => console.log('[Shoukaku] Player closed:', data));

            } catch (error) {
                console.error('[Shoukaku] Failed to join voice channel:', error);
                return interaction.editReply({ embeds: [createErrorEmbed('Failed to join the voice channel.')] });
            }
        }

        let searchStr = query;
        if (!query.startsWith('http://') && !query.startsWith('https://')) {
            searchStr = `ytsearch:${query}`;
        }

        const result = await node.rest.resolve(searchStr);
        if (!result || !result.data || (Array.isArray(result.data) && result.data.length === 0)) {
            return interaction.editReply({ embeds: [createErrorEmbed('No results found matching your query.')] });
        }

        // Add a simple queue array to the player object if not exists
        if (!player.queue) player.queue = [];

        console.log(`[Play Command] Current track state:`, player.track);
        console.log(`[Play Command] Load type:`, result.loadType);

        if (result.loadType === 'playlist') {
            const tracks = result.data.tracks;
            player.queue.push(...tracks);

            if (!player.track) {
                console.log(`[Play Command] Nothing playing, starting playlist immediately.`);
                await player.playTrack({ track: { encoded: player.queue.shift().encoded } });
            } else {
                console.log(`[Play Command] Added playlist to queue. Currently playing something.`);
            }

            const embed = createSuccessEmbed(`Added ${tracks.length} tracks from playlist **${result.data.info.name}**`);
            return interaction.editReply({ embeds: [embed] });
        } else if (result.loadType === 'track') {
            const track = result.data;
            player.queue.push(track);

            if (!player.track) {
                console.log(`[Play Command] Nothing playing, starting track immediately.`);
                await player.playTrack({ track: { encoded: player.queue.shift().encoded } });
            } else {
                console.log(`[Play Command] Added track to queue. Currently playing something.`);
            }

            const embed = createSuccessEmbed(`Added **${track.info.title}** to the queue.`);
            return interaction.editReply({ embeds: [embed] });
        }

        // Fallback for search results (array of tracks from ytsearch)
        const track = result.data[0];
        player.queue.push(track);

        if (!player.track) {
            console.log(`[Play Command] Nothing playing, starting search track immediately.`);
            await player.playTrack({ track: { encoded: player.queue.shift().encoded } });
        } else {
            console.log(`[Play Command] Added search track to queue. Currently playing something.`);
        }

        const embed = createSuccessEmbed(`Added **${track.info.title}** to the queue.`);
        return interaction.editReply({ embeds: [embed] });

    }
};
