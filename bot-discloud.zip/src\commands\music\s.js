const { SlashCommandBuilder } = require('discord.js');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('s')
        .setDescription('Skip the current song'),
    async execute(interaction, client) {
        const player = client.shoukaku.players.get(interaction.guild.id);
        if (!player) return interaction.reply({ embeds: [createErrorEmbed('No music is playing!')], ephemeral: true });

        await player.stopTrack(); // Triggers the 'end' event to play the next song
        return interaction.reply({ embeds: [createSuccessEmbed('Skipped the current track.')] });
    }
};
