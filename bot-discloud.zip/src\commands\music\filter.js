const { SlashCommandBuilder } = require('discord.js');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('filter')
        .setDescription('Apply audio filters')
        .addStringOption(option =>
            option.setName('type')
                .setDescription('The filter to apply')
                .setRequired(true)
                .addChoices(
                    { name: 'Bassboost', value: 'bassboost' },
                    { name: 'Nightcore', value: 'nightcore' },
                    { name: 'Vaporwave', value: 'vaporwave' },
                    { name: 'Clear', value: 'clear' }
                )
        ),

    async execute(interaction, client) {
        const player = client.shoukaku.players.get(interaction.guild.id);
        if (!player) return interaction.reply({ embeds: [createErrorEmbed('No music is playing!')], ephemeral: true });

        const filter = interaction.options.getString('type');

        await interaction.deferReply();

        if (filter === 'clear') {
            await player.clearFilters();
            return interaction.editReply({ embeds: [createSuccessEmbed('Filters cleared.')] });
        }

        if (filter === 'bassboost') {
            await player.setFilters({
                equalizer: [
                    { band: 0, gain: 0.2 },
                    { band: 1, gain: 0.15 },
                    { band: 2, gain: 0.1 },
                ]
            });
        } else if (filter === 'nightcore') {
            await player.setFilters({
                timescale: { speed: 1.2, pitch: 1.2, rate: 1.0 }
            });
        } else if (filter === 'vaporwave') {
            await player.setFilters({
                timescale: { speed: 0.85, pitch: 0.8, rate: 1.0 }
            });
        }

        interaction.editReply({ embeds: [createSuccessEmbed(`Applied **${filter}** filter.`)] });
    }
};
