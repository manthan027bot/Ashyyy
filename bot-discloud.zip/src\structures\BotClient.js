const { Client, Collection, GatewayIntentBits, Partials } = require('discord.js');
const { Shoukaku, Connectors } = require('shoukaku');
const fs = require('fs');
const path = require('path');

class BotClient extends Client {
    constructor() {
        super({
            intents: [
                GatewayIntentBits.Guilds,
                GatewayIntentBits.GuildVoiceStates,
                GatewayIntentBits.GuildMessages,
                GatewayIntentBits.MessageContent
            ],
            partials: [Partials.Channel, Partials.Message, Partials.User, Partials.GuildMember]
        });

        this.commands = new Collection();
        this.config = process.env;

        const nodes = [{
            name: 'Local Node',
            url: `${process.env.LAVALINK_HOST}:${process.env.LAVALINK_PORT}`,
            auth: process.env.LAVALINK_PASSWORD,
            secure: process.env.LAVALINK_SECURE === 'true'
        }];

        this.shoukaku = new Shoukaku(new Connectors.DiscordJS(this), nodes, {
            moveOnDisconnect: true,
            resumable: true,
            resumableTimeout: 30,
            reconnectTries: 5,
            restTimeout: 10000
        });

        this.shoukaku.on('error', (_, error) => console.error('[Shoukaku] Error:', error));
        this.shoukaku.on('ready', (name) => console.log(`[Shoukaku] Node ${name} is now connected`));
        this.shoukaku.on('close', (name, code, reason) => console.log(`[Shoukaku] Node ${name} closed with code ${code}. Reason: ${reason || 'No reason'}`));
        this.shoukaku.on('disconnect', (name, count) => console.log(`[Shoukaku] Node ${name} disconnected. Reconnecting... (Attempt: ${count})`));
        this.shoukaku.on('debug', (name, info) => console.log(`[Shoukaku Debug|${name}]`, info));
    }

    async start() {
        await this.loadHandlers();
        await this.login(this.config.TOKEN);
    }

    async loadHandlers() {
        const handlersPath = path.join(__dirname, '../handlers');
        const handlerFiles = fs.readdirSync(handlersPath).filter(file => file.endsWith('.js'));

        for (const file of handlerFiles) {
            require(`../handlers/${file}`)(this);
        }
    }
}

module.exports = BotClient;
