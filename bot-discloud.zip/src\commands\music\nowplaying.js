const { SlashCommandBuilder } = require('discord.js');
const { createErrorEmbed } = require('../../utils/embeds');
const { buildNowPlayingMenu } = require('../../utils/musicMenu');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('nowplaying')
        .setDescription('Shows the currently playing song with interactive controls'),

    async execute(interaction, client) {
        const player = client.shoukaku.players.get(interaction.guild.id);

        if (!player || !player.track) {
            return interaction.reply({ embeds: [createErrorEmbed('There is no music currently playing.')], ephemeral: true });
        }

        const menuPayload = await buildNowPlayingMenu(client, player);
        if (!menuPayload) {
            return interaction.reply({ embeds: [createErrorEmbed('Could not retrieve track information.')], ephemeral: true });
        }

        await interaction.reply(menuPayload);
    }
};
