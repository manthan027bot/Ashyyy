const { SlashCommandBuilder } = require('discord.js');
const autoplayCommand = require('./autoplay');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ap')
        .setDescription('Alias for /autoplay'),
    async execute(interaction, client) {
        return autoplayCommand.execute(interaction, client);
    }
};
