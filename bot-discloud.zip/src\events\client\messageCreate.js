const { Events } = require('discord.js');
const { getPrefix } = require('../../utils/prefixManager');

module.exports = {
    name: Events.MessageCreate,
    async execute(message, client) {
        if (message.author.bot || !message.guild) return;

        const prefix = getPrefix(message.guild.id);
        const isNoPrefixMode = prefix === 'none';

        let content = message.content.trim();
        let commandName = '';
        let args = [];

        if (isNoPrefixMode) {
            // No prefix mode: just split by spaces
            const argsRaw = content.split(/ +/);
            commandName = argsRaw.shift().toLowerCase();
            args = argsRaw;
        } else {
            // Standard prefix mode
            if (!content.startsWith(prefix)) return;
            const argsRaw = content.slice(prefix.length).trim().split(/ +/);
            commandName = argsRaw.shift().toLowerCase();
            args = argsRaw;
        }

        const command = client.commands.get(commandName);
        if (!command) return;

        // Mock an Interaction object so we don't have to rewrite slash commands
        const mockInteraction = {
            isCommand: () => true,
            isChatInputCommand: () => true,
            isContextMenuCommand: () => false,
            client: client,
            guild: message.guild,
            channel: message.channel,
            user: message.author,
            member: message.member,
            commandName: commandName,
            options: {
                getString: (name) => {
                    // Quick hack since our music bot uses string options heavily
                    if (name === 'query' || name === 'song') return args.join(' ');
                    if (name === 'mode') return args[0]; // for /loop mode
                    if (name === 'filter') return args[0]; // for /filter type
                    return args.join(' ');
                },
                getSubcommand: () => null
            },
            reply: async (data) => {
                if (typeof data === 'string') data = { content: data };
                if (data.ephemeral !== undefined) delete data.ephemeral;
                return message.channel.send(data);
            },
            editReply: async (data) => {
                if (typeof data === 'string') data = { content: data };
                if (data.ephemeral !== undefined) delete data.ephemeral;
                return message.channel.send(data);
            },
            followUp: async (data) => {
                if (typeof data === 'string') data = { content: data };
                if (data.ephemeral !== undefined) delete data.ephemeral;
                return message.channel.send(data);
            },
            deferReply: async () => { }, // do nothing but trick the command
        };

        try {
            await command.execute(mockInteraction, client);
        } catch (error) {
            console.error(error);
            message.channel.send('There was an error while executing this command through text!');
        }
    },
};
