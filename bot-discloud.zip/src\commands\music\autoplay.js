const { SlashCommandBuilder } = require('discord.js');
const { createSuccessEmbed, createErrorEmbed } = require('../../utils/embeds');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('autoplay')
        .setDescription('Toggle autoplay'),

    async execute(interaction, client) {
        const player = client.shoukaku.players.get(interaction.guild.id);
        if (!player) return interaction.reply({ embeds: [createErrorEmbed('No music is playing!')], ephemeral: true });

        player.isAutoplay = !player.isAutoplay;

        return interaction.reply({ embeds: [createSuccessEmbed(`Autoplay is now **${player.isAutoplay ? 'Enabled' : 'Disabled'}**.`)] });
    }
};
